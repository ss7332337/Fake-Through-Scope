#include <d3d11.h>
//#include <unordered_set>
//#include <iostream>
#include "ReshadeImpl.h"
#include "FTSData.h"
#include "RE/Havok/hkVector4.h"


using namespace RE;
using namespace BSScript;
using namespace std;



bool bNeedToUpdateFTSData = true;
bool bChangeAnimFlag = false;
bool nvgFlag = false;
bool hasCombo = false;
bool hasNvgCommit = false;
bool InGameFlag = false;
bool IsHooked = false;
bool bHasStartedScope = false;
bool testingFlag = false;

ReshadeImpl::Impl* reshadeImpl;
ScopeData::ScopeDataHandler* sdh;
PlayerCharacter* player;
PlayerCamera* pcam;

RE::BGSKeyword* an_45;
RE::BGSKeyword* AnimsXM2010_scopeKH45;
RE::BGSKeyword* AnimsXM2010_scopeKM;
RE::BGSKeyword* AnimsAX50_scopeKH45;
RE::BGSKeyword* QMW_AnimsQBZ191M_on;
RE::BGSKeyword* QMW_AnimsQBZ191M_off;
RE::BGSKeyword* QMW_AnimsRU556M_on;
RE::BGSKeyword* QMW_AnimsRU556M_off;
RE::BGSKeyword* Tull_SideAimKeyword;
RE::BGSKeyword* Tull_SupportKeyword;

RE::NiAVObject* scopeNode;
RE::NiAVObject* camNode;
RE::NiAVObject* weaponNode;
RE::NiAVObject* rootNode;
PlayerControls* pc;
HMODULE Upscaler;

hkVector4f lastPosition;
hkVector4f currPosition;



REL::Relocation<uintptr_t> ptr_PCUpdateMainThread{ REL::ID(633524), 0x22D };
uintptr_t PCUpdateMainThreadOrig;


BGSKeyword* ChangeAnimFlavorKeyword = nullptr;
ScopeData::FTSData* currentData;
const char* customPath = "Data\\F4SE\\Plugins\\FTS";

template <class Ty>
Ty SafeWrite64Function(uintptr_t addr, Ty data)
{
	DWORD oldProtect;
	void* _d[2];
	memcpy(_d, &data, sizeof(data));
	size_t len = sizeof(_d[0]);

	VirtualProtect((void*)addr, len, PAGE_EXECUTE_READWRITE, &oldProtect);
	Ty olddata;
	memset(&olddata, 0, sizeof(Ty));
	memcpy(&olddata, (void*)addr, len);
	memcpy((void*)addr, &_d[0], len);
	VirtualProtect((void*)addr, len, oldProtect, &oldProtect);
	return olddata;
}

struct TESEquipEvent
{
	Actor* a;         //00
	uint32_t formId;  //0C
	uint32_t unk08;   //08
	uint64_t flag;    //10 0x00000000ff000000 for unequip
};

class EquipEventSource : public BSTEventSource<TESEquipEvent>
{
public:
	[[nodiscard]] static EquipEventSource* GetSingleton()
	{
		REL::Relocation<EquipEventSource*> singleton{ REL::ID(485633) };
		return singleton.get();
	}
};

TESForm* GetFormFromMod(std::string modname, uint32_t formid)
{
	if (!modname.length() || !formid)
		return nullptr;
	TESDataHandler* dh = TESDataHandler::GetSingleton();
	TESFile* modFile = nullptr;
	for (auto it = dh->files.begin(); it != dh->files.end(); ++it) {
		TESFile* f = *it;
		if (strcmp(f->filename, modname.c_str()) == 0) {
			modFile = f;
			break;
		}
	}
	if (!modFile)
		return nullptr;
	uint8_t modIndex = modFile->compileIndex;
	uint32_t id = formid;
	if (modIndex < 0xFE) {
		id |= ((uint32_t)modIndex) << 24;
	} else {
		uint16_t lightModIndex = modFile->smallFileCompileIndex;
		if (lightModIndex != 0xFFFF) {
			id |= 0xFE000000 | (uint32_t(lightModIndex) << 12);
		}
	}
	return TESForm::GetFormByID(id);
}


void WorldToScreen_Internal(RE::NiPoint3* in, RE::NiPoint3* out)
{
	using func_t = decltype(&WorldToScreen_Internal);
	REL::Relocation<func_t> func{ REL::ID(1132313) };
	return func(in, out);
}

DWORD StartHooking(LPVOID)
{
	/*Hook::D3D::Register();*/
	reshadeImpl->InitReshadeImpl(((HMODULE)F4SE::WinAPI::GetCurrentModule()));
	return 0;
}


bool IssueChangeAnim(std::monostate, BGSKeyword* keyword)
{
	bChangeAnimFlag = true;
	ChangeAnimFlavorKeyword = keyword;

	return true;
}

bool TestButton(std::monostate)
{
	/*BGSKeyword* tkeyword = (BGSKeyword*)TESForm::GetFormByEditorID("QMW_AnimsQBZ191M_on");
	reshadeImpl->SetTestFlag(true);
	IssueChangeAnimInternal(tkeyword);*/

	//player->Get3D(true)->GetObjectByName()

	/*testingFlag = !testingFlag;
	reshadeImpl->SetTestFlag(testingFlag);*/

	return true;
}



bool IsInADS(Actor* a)
{
	return (a->gunState == GUN_STATE::kSighted || a->gunState == GUN_STATE::kFireSighted);
}


bool IsSideAim()
{
	bool temp;
	if (player) 
	{
		if (an_45) {
			temp = player->HasKeyword(an_45, reinterpret_cast<RE::TBO_InstanceData*>(player));
			return temp;
		}
		else if (AnimsXM2010_scopeKH45) {
			temp = player->HasKeyword(AnimsXM2010_scopeKH45, reinterpret_cast<RE::TBO_InstanceData*>(player));
			return temp;
		}
		else if (AnimsXM2010_scopeKM) {
			temp = player->HasKeyword(AnimsXM2010_scopeKM, reinterpret_cast<RE::TBO_InstanceData*>(player));
			return temp;
		} 
		else if (AnimsAX50_scopeKH45) {
			temp = player->HasKeyword(AnimsXM2010_scopeKM, reinterpret_cast<RE::TBO_InstanceData*>(player));
			return temp;
		} 
		else if (Tull_SideAimKeyword) {
			temp = player->HasKeyword(Tull_SideAimKeyword, reinterpret_cast<RE::TBO_InstanceData*>(player));
			return temp;
		}
	}
	return false;
}

BGSKeyword* IsMagnifier()
{

	if (player) {
		if (QMW_AnimsQBZ191M_on) {
			if (player->HasKeyword(QMW_AnimsQBZ191M_on, reinterpret_cast<RE::TBO_InstanceData*>(player)))
				return QMW_AnimsQBZ191M_on;
		} else if (QMW_AnimsQBZ191M_off) {
			if (player->HasKeyword(QMW_AnimsQBZ191M_off, reinterpret_cast<RE::TBO_InstanceData*>(player)))
				return QMW_AnimsQBZ191M_off;
		} else if (QMW_AnimsRU556M_off) {
			if (player->HasKeyword(QMW_AnimsRU556M_off, reinterpret_cast<RE::TBO_InstanceData*>(player)))
				return QMW_AnimsRU556M_off;
		} else if (QMW_AnimsRU556M_on) {
			if (player->HasKeyword(QMW_AnimsRU556M_on, reinterpret_cast<RE::TBO_InstanceData*>(player)))
				return QMW_AnimsRU556M_on;
		}
	}
	return nullptr;
}


inline void InitCurrentScopeData(BGSKeyword* animFlavorKeyword)
{
	if (player->currentProcess) {
		//_MESSAGE("Equipping Process!!!");
		BSTArray<EquippedItem>& eventEquipped = player->currentProcess->middleHigh->equippedItems;

		if (eventEquipped.size() > 0 && eventEquipped[0].item.instanceData &&
			((TESObjectWEAP::InstanceData*)eventEquipped[0].item.instanceData.get())->type == 9) {
			//_MESSAGE("Equipping EveryThing Done!!!");
			TESObjectWEAP* eventWep = ((TESObjectWEAP*)eventEquipped[0].item.object);
			TESObjectWEAP::InstanceData* eventInstance = (TESObjectWEAP::InstanceData*)eventEquipped[0].item.instanceData.get();

			if (!eventInstance || !eventInstance->GetKeywordData())
				return;

			BSScrapArray<const BGSKeyword*> playerkeywords;
			player->CollectAllKeywords(playerkeywords, reinterpret_cast<TBO_InstanceData*>(player));

			for (uint32_t i = 0; i < eventInstance->GetKeywordData()->numKeywords; i++) {
				std::string_view tempKeywordEditorID = eventInstance->GetKeywordData()->keywords[i]->formEditorID.c_str();

				if (tempKeywordEditorID.starts_with("FTS_")) {
					if (playerkeywords.size() > 0) {

						size_t len = sdh->GetScopeDataMap()->count(tempKeywordEditorID.data());

						if (len == 0)
							return;

						std::map<std::string, ScopeData::FTSData*>::iterator it = sdh->GetScopeDataMap()->find(tempKeywordEditorID.data());

						if (len > 0) {

							if (animFlavorKeyword) {
								for (size_t kk = 0; kk < len; ++kk, ++it) {
									for (auto j : playerkeywords) {
										if (j == animFlavorKeyword) {
											sdh->SetCurrentFTSData(it->second);
											reshadeImpl->UpdateTexture();
											return;
										}
									}
								}
							}

							it = sdh->GetScopeDataMap()->find(tempKeywordEditorID.data());

							for (size_t kk = 0; kk < len; ++kk, ++it) {
								string animKeyword = it->second->animFlavorEditorID;

								if (animKeyword.compare("FTS_NONE") == 0 || animKeyword.compare("")== 0) {
									sdh->SetCurrentFTSData(it->second);
									reshadeImpl->UpdateTexture();
									return;
								}
							}
						}
					}
				}
			}

			sdh->SetCurrentFTSData(nullptr);
		}
	}
}


class InputEventReceiverOverride : public BSInputEventReceiver
{
public:
	typedef void (InputEventReceiverOverride::*FnPerformInputProcessing)(const InputEvent* a_queueHead);

	//using Virtual-Key Codes
	void ProcessButtonEvent(ButtonEvent* evn)
	{
		{
			if (evn->eventType != INPUT_EVENT_TYPE::kButton) {
				if (evn->next)
					ProcessButtonEvent((ButtonEvent*)evn->next);
				return;
			}

			uint32_t id = evn->idCode;
			if (evn->device == INPUT_DEVICE::kMouse)
				id += 0x100;
			if (evn->device == INPUT_DEVICE::kGamepad)
				id += 0x10000;
#ifdef Debug
			if (evn->device == INPUT_DEVICE::kKeyboard && id == VK_OEM_PERIOD && evn->JustPressed()) {
				std::monostate mono;
				TestButton(mono);
			}
#endif 

			
			if (currentData && evn->device == INPUT_DEVICE::kKeyboard) {
				if (sdh->comboNVKey == -1) {
					if (id == (uint32_t)sdh->nvKey && evn->JustPressed()) {
						nvgFlag = !nvgFlag;
						reshadeImpl->SetNVG(nvgFlag);
					}
				} else {
					if (id == (uint32_t)(sdh->comboNVKey) && evn->heldDownSecs > 0 && evn->value == 1) {
						hasCombo = true;
					}

					if (id == (uint32_t)(sdh->comboNVKey) && evn->value == 0) {
						hasCombo = false;
					}

					if (hasCombo && id == (uint32_t)sdh->nvKey && evn->JustPressed()) {
						nvgFlag = !nvgFlag;
						reshadeImpl->SetNVG(nvgFlag);
					}
				}
			}
		}
	
		
	
	}

	void HookedPerformInputProcessing(const InputEvent* a_queueHead)
	{
		if (!UI::GetSingleton()->menuMode && !UI::GetSingleton()->GetMenuOpen("LooksMenu") && !UI::GetSingleton()->GetMenuOpen("ScopeMenu") && a_queueHead) {
			ProcessButtonEvent((ButtonEvent*)a_queueHead);
		}
		
		FnPerformInputProcessing fn = fnHash.at(*(uint64_t*)this);
		if (fn) {
			(this->*fn)(a_queueHead);
		}
	}

	void HookSink()
	{
		uint64_t vtable = *(uint64_t*)this;
		auto it = fnHash.find(vtable);
		if (it == fnHash.end()) {
			FnPerformInputProcessing fn = SafeWrite64Function(vtable, &InputEventReceiverOverride::HookedPerformInputProcessing);
			fnHash.insert(std::pair<uint64_t, FnPerformInputProcessing>(vtable, fn));
		}
	}

	void UnHookSink()
	{
		uint64_t vtable = *(uint64_t*)this;
		auto it = fnHash.find(vtable);
		if (it == fnHash.end())
			return;
		SafeWrite64Function(vtable, it->second);
		fnHash.erase(it);
	}

protected:
	static unordered_map<uint64_t, FnPerformInputProcessing> fnHash;
};
unordered_map<uint64_t, InputEventReceiverOverride::FnPerformInputProcessing> InputEventReceiverOverride::fnHash;




namespace RE
{
	class hkTransformf
	{
	public:
		void setIdentity()
		{
			m_rotation.MakeIdentity();
			m_translation = hkVector4f();
		}
		NiMatrix3 m_rotation;
		hkVector4f m_translation;
	};
	typedef hkTransformf hkTransform;
}


void HookedUpdate()
{
	/*if (!IsHooked) {
		
		IsHooked = true;
	}*/
	if (InGameFlag&& player && player->Get3D(true)) {
		scopeNode = player->Get3D(true)->GetObjectByName("FTS:CenterPoint");
		camNode = player->Get3D(true)->GetObjectByName("Camera");
		rootNode = player->Get3D(true)->GetObjectByName("RArm_UpperArm");
		NiAVObject* RealRootNode = player->Get3D(true);
		pc = PlayerControls::GetSingleton();
		
		//MenuCursor::GetSingleton()->CenterCursor();
		
		NiPointer<bhkCharacterController> con = player->currentProcess->middleHigh->charController;
		uintptr_t charProxy = *(uintptr_t*)((uintptr_t)con.get() + 0x470);
		hkTransform* charProxyTransform = (hkTransform*)(charProxy + 0x40);

		if (!reshadeImpl)
			return;


		if (scopeNode && camNode && rootNode) 
		{
			currPosition = charProxyTransform->m_translation;
			hkVector4f VirTransLerp = currPosition - lastPosition;
			lastPosition = currPosition;

			NiPoint3 virDir = scopeNode->world.translate - camNode->world.translate;
			NiPoint3 lastVirDir = scopeNode->previousWorld.translate - camNode->previousWorld.translate;
			NiPoint3 VirDirLerp = NiPoint3( virDir - lastVirDir);
			
			NiPoint3 weaponPos = scopeNode->world.translate;
			NiPoint3 rootPos = camNode->world.translate;

			//NiPoint3 out;
			//WorldToScreen_Internal(&weaponPos, &out);


			reshadeImpl->SetVirDir(virDir);
			reshadeImpl->SetLastVirDir(lastVirDir);
			reshadeImpl->SetVirDirLerp(VirDirLerp);
			reshadeImpl->SetVirTransLerp(VirTransLerp);
			reshadeImpl->SetWeaponPos(weaponPos);
			reshadeImpl->SetRootPos(rootPos);
			reshadeImpl->SetCamMat(camNode->world.rotate);

			reshadeImpl->SetShaderData();
		}
	}
	

	typedef void (*FnUpdate)();
	FnUpdate fn = (FnUpdate)PCUpdateMainThreadOrig;
	if (fn)
		(*fn)();
}



//装备事件
class EquipWatcher : public BSTEventSink<TESEquipEvent>
{
public:
	virtual BSEventNotifyControl ProcessEvent(const TESEquipEvent& evn, BSTEventSource<TESEquipEvent>* a_source)
	{
		Actor* a = evn.a;

		if (a == player) {

			TESForm* item = TESForm::GetFormByID(evn.formId);
			/*reshade::log_message(4, "" + evn.formId);
			reshade::log_message(4, "Player!");*/
			
			if (evn.flag == 0x00000000ff000000) {
				
			}

			
			if (evn.flag != 0x00000000ff000000 && item && item->formType == ENUM_FORM_ID::kWEAP) {
				sdh->SetCurrentFTSData(nullptr);
				InitCurrentScopeData(nullptr);
				reshadeImpl->SetInterfaceTextRefresh(true);
				bChangeAnimFlag = false;
			}
		}
		
		return BSEventNotifyControl::kContinue;
	}
	F4_HEAP_REDEFINE_NEW(EquipWatcher);
};




using std::unordered_map;
class AnimationGraphEventWatcher
{
public:
	typedef BSEventNotifyControl (AnimationGraphEventWatcher::*FnProcessEvent)(BSAnimationGraphEvent& evn, BSTEventSource<BSAnimationGraphEvent>* dispatcher);

	BSEventNotifyControl HookedProcessEvent(BSAnimationGraphEvent& evn, BSTEventSource<BSAnimationGraphEvent>* src)
	{
		FnProcessEvent fn = fnHash.at(*(uint64_t*)this);
		string prefix = "";

		if (IsInADS(player)) {

			BGSKeyword* magKeyword = IsMagnifier();
			if (magKeyword != nullptr) {
				bChangeAnimFlag = true;
				ChangeAnimFlavorKeyword = magKeyword;
			}

			/*ostringstream oss;
			oss << evn.animEvent.c_str() << ", " << evn.argument.c_str();
			reshade::log_message(4, oss.str().c_str());*/
			if (!IsSideAim() && !player->IsInThirdPerson() && bNeedToUpdateFTSData) {

				if (bChangeAnimFlag) {
					InitCurrentScopeData(ChangeAnimFlavorKeyword);
					//bChangeAnimFlag = false;
				} else {
					InitCurrentScopeData(nullptr);
				}

				currentData = sdh->GetCurrentFTSData();

				if (currentData && !bHasStartedScope) {

					reshadeImpl->StartScope(true);
					reshadeImpl->SetFinishAimAnim(true);
					bHasStartedScope = true;
				}

				bNeedToUpdateFTSData = false;
			}
		} else{
			reshadeImpl->StartScope(false);
			bNeedToUpdateFTSData = true;
			reshadeImpl->SetAreaCopy(false);
			bHasStartedScope = false;	
		}


		return fn ? (this->*fn)(evn, src) : BSEventNotifyControl::kContinue;
	}

	void HookSink()
	{
		uint64_t vtable = *(uint64_t*)this;
		auto it = fnHash.find(vtable);
		if (it == fnHash.end()) {
			FnProcessEvent fn = SafeWrite64Function(vtable + 0x8, &AnimationGraphEventWatcher::HookedProcessEvent);
			fnHash.insert(std::pair<uint64_t, FnProcessEvent>(vtable, fn));
		}
	}

	void UnHookSink()
	{
		uint64_t vtable = *(uint64_t*)this;
		auto it = fnHash.find(vtable);
		if (it == fnHash.end())
			return;
		SafeWrite64Function(vtable + 0x8, it->second);
		fnHash.erase(it);
	}

protected:
	static unordered_map<uint64_t, FnProcessEvent> fnHash;
};
unordered_map<uint64_t, AnimationGraphEventWatcher::FnProcessEvent> AnimationGraphEventWatcher::fnHash;







bool RegisterFuncs(BSScript::IVirtualMachine* vm)
{
	stl::zstring fileName = "FakeThroughScope";
	//vm->BindNativeMethod(fileName, "TestButton", TestButton);

	vm->BindNativeMethod(fileName, "OnChangeAnimFlavor", IssueChangeAnim);


	return true;
}

void InitializePlugin()
{
	player = PlayerCharacter::GetSingleton();

	pcam = PlayerCamera::GetSingleton();
	((InputEventReceiverOverride*)((uint64_t)pcam + 0x38))->HookSink();
	
	an_45 = (RE::BGSKeyword*)RE::TESForm::GetFormByEditorID("an_45d");
	AnimsXM2010_scopeKH45 = (RE::BGSKeyword*)RE::TESForm::GetFormByEditorID("AnimsXM2010_scopeKH45");
	AnimsXM2010_scopeKM = (RE::BGSKeyword*)RE::TESForm::GetFormByEditorID("AnimsXM2010_scopeKM");
	AnimsAX50_scopeKH45 = (RE::BGSKeyword*)RE::TESForm::GetFormByEditorID("AnimsAX50_scopeKH45");
	Tull_SideAimKeyword = (BGSKeyword*)GetFormFromMod("Tull_Framework.esp", 0x804);
	Tull_SupportKeyword = (BGSKeyword*)GetFormFromMod("Tull_Framework.esp", 0x804);

	QMW_AnimsQBZ191M_on = (RE::BGSKeyword*)RE::TESForm::GetFormByEditorID("QMW_AnimsQBZ191M_on");
	QMW_AnimsQBZ191M_off = (RE::BGSKeyword*)RE::TESForm::GetFormByEditorID("QMW_AnimsQBZ191M_off");
	QMW_AnimsRU556M_on = (RE::BGSKeyword*)RE::TESForm::GetFormByEditorID("QMW_AnimsRU556M_on");
	QMW_AnimsRU556M_off = (RE::BGSKeyword*)RE::TESForm::GetFormByEditorID("QMW_AnimsRU556M_off");

	sdh = ScopeData::ScopeDataHandler::GetSingleton();

	((AnimationGraphEventWatcher*)((uint64_t)PlayerCharacter::GetSingleton() + 0x38))->HookSink();
	

	EquipWatcher* ew = new EquipWatcher();
	EquipEventSource::GetSingleton()->RegisterSink(ew);

	Upscaler = GetModuleHandleA("Fallout4Upscaler.dll");

	reshadeImpl->SetIsUpscaler(Upscaler);
	sdh->SetIsUpscaler(Upscaler);

	sdh->ReadCustomScopeDataFiles(customPath);
	sdh->ReadDefaultScopeDataFile();
	
}

void ResetScopeStatus()
{
	reshadeImpl->InitPlayerAndCam(player, pcam);
	reshadeImpl->InitOffset(true);
	reshadeImpl->SetRenderEffect(true);
	InitCurrentScopeData(nullptr);
	InGameFlag = true;
}




extern "C" DLLEXPORT bool F4SEAPI F4SEPlugin_Query(const F4SE::QueryInterface* a_f4se, F4SE::PluginInfo* a_info)
{
#ifndef NDEBUG
	auto sink = std::make_shared<spdlog::sinks::msvc_sink_mt>();
#else
	auto path = logger::log_directory();
	if (!path) {
		return false;
	}

	*path /= fmt::format(FMT_STRING("{}.log"), Version::PROJECT);
	auto sink = std::make_shared<spdlog::sinks::basic_file_sink_mt>(path->string(), true);
#endif

	auto log = std::make_shared<spdlog::logger>("global log"s, std::move(sink));

#ifndef NDEBUG
	log->set_level(spdlog::level::trace);
#else
	log->set_level(spdlog::level::info);
	log->flush_on(spdlog::level::warn);
#endif

	spdlog::set_default_logger(std::move(log));
	spdlog::set_pattern("%g(%#): [%^%l%$] %v"s);

	logger::info(FMT_STRING("{} v{}"), Version::PROJECT, Version::NAME);

	a_info->infoVersion = F4SE::PluginInfo::kVersion;
	a_info->name = Version::PROJECT.data();
	a_info->version = Version::MAJOR;

	if (a_f4se->IsEditor()) {
		logger::critical("loaded in editor"sv);
		return false;
	}

	const auto ver = a_f4se->RuntimeVersion();
	if (ver < F4SE::RUNTIME_1_10_162) {
		logger::critical(FMT_STRING("unsupported runtime v{}"), ver.string());
		return false;
	}
	

	reshadeImpl = &(ReshadeImpl::Impl::instance());
	

	HANDLE hThread = CreateThread(NULL, 0, StartHooking, NULL, 0, NULL);

	
	F4SE::AllocTrampoline(8 * 8);

	return true;
}


extern "C" DLLEXPORT bool F4SEAPI F4SEPlugin_Load(const F4SE::LoadInterface* a_f4se)
{
	F4SE::Init(a_f4se);

	F4SE::Trampoline& trampoline = F4SE::GetTrampoline();
	PCUpdateMainThreadOrig = trampoline.write_call<5>(ptr_PCUpdateMainThread.address(), &HookedUpdate);

	const F4SE::PapyrusInterface* papyrus = F4SE::GetPapyrusInterface();
	bool succ = papyrus->Register(RegisterFuncs);
	if (succ) {
		logger::warn("succ.");
	}

	const F4SE::MessagingInterface* message = F4SE::GetMessagingInterface();
	message->RegisterListener([](F4SE::MessagingInterface::Message* msg) -> void {

		if (msg->type == F4SE::MessagingInterface::kGameDataReady) {
			InitializePlugin();

		} else if (msg->type == F4SE::MessagingInterface::kPostLoadGame) {
			ResetScopeStatus();
		} else if (msg->type == F4SE::MessagingInterface::kNewGame) {
			ResetScopeStatus();
		}
		else if (msg->type == F4SE::MessagingInterface::kPostSaveGame) {
			reshadeImpl->SetRenderEffect(true);
		}
		else {
			reshadeImpl->SetRenderEffect(false);	
		}

	});

	return true;
}
