#pragma once
#include "RE/NetImmerse/NiMatrix3.h"
#include "RE/NetImmerse/NiPoint3.h"
#include <cmath>
#include <cstdint>

#ifndef MATH_PI
#	define MATH_PI 3.14159265358979323846
#endif
using RE::NiMatrix3;
using RE::NiPoint3;

float toRad = (float)(MATH_PI / 180.0);



typedef std::array<float, 3> float3;
typedef std::array<float3, 3> float3x3;

const float PI = 3.14159265358979323846264f;

bool closeEnough(const float& a, const float& b, const float& epsilon = std::numeric_limits<float>::epsilon())
{
	return (epsilon > std::abs(a - b));
}

float3 eulerAngles(const float3x3& R)
{
	//check for gimbal lock
	if (closeEnough(R[0][2], -1.0f)) {
		float x = 0;  //gimbal lock, value of x doesn't matter
		float y = PI / 2;
		float z = x + atan2(R[1][0], R[2][0]);
		return { x, y, z };
	} else if (closeEnough(R[0][2], 1.0f)) {
		float x = 0;
		float y = -PI / 2;
		float z = -x + atan2(-R[1][0], -R[2][0]);
		return { x, y, z };
	} else {  //two solutions exist
		float x1 = -asin(R[0][2]);
		float x2 = PI - x1;

		float y1 = atan2(R[1][2] / cos(x1), R[2][2] / cos(x1));
		float y2 = atan2(R[1][2] / cos(x2), R[2][2] / cos(x2));

		float z1 = atan2(R[0][1] / cos(x1), R[0][0] / cos(x1));
		float z2 = atan2(R[0][1] / cos(x2), R[0][0] / cos(x2));

		//choose one solution to return
		//for example the "shortest" rotation
		if ((std::abs(x1) + std::abs(y1) + std::abs(z1)) <= (std::abs(x2) + std::abs(y2) + std::abs(z2))) {
			return { x1, y1, z1 };
		} else {
			return { x2, y2, z2 };
		}
	}
}


struct Quaternion
{
public:
	float x, y, z, w;
	Quaternion(float _x, float _y, float _z, float _w);
	float Norm();
	NiMatrix3 ToRotationMatrix33();
};

Quaternion::Quaternion(float _x, float _y, float _z, float _w)
{
	x = _x;
	y = _y;
	z = _z;
	w = _w;
}

float Quaternion::Norm()
{
	return x * x + y * y + z * z + w * w;
}


class NiMatrix4
{
public:
	void MakeIdentity() noexcept
	{
		entry[0].v = { 1.0F, 0.0F, 0.0F, 0.0F };
		entry[1].v = { 0.0F, 1.0F, 0.0F, 0.0F };
		entry[2].v = { 0.0F, 0.0F, 1.0F, 0.0F };
		entry[3].v = { 0.0F, 0.0F, 0.0F, 1.0F };
	}

	// members
	RE::NiPoint4 entry[4];  // 00


	RE::NiPoint4 operator*(const RE::NiPoint4& p) const
	{
		return RE::NiPoint4{
			entry[0].pt[0] * p.v.x + entry[0].pt[1] * p.v.y + entry[0].pt[2] * p.v.z + entry[0].pt[3] * p.v.w,
			entry[1].pt[0] * p.v.x + entry[1].pt[1] * p.v.y + entry[1].pt[2] * p.v.z + entry[1].pt[3] * p.v.w,
			entry[2].pt[0] * p.v.x + entry[2].pt[1] * p.v.y + entry[2].pt[2] * p.v.z + entry[2].pt[3] * p.v.w,
			entry[3].pt[0] * p.v.x + entry[3].pt[1] * p.v.y + entry[3].pt[2] * p.v.z + entry[3].pt[3] * p.v.w
		};
	}
};

NiMatrix4 ToQ(const RE::NiMatrix3& p)
{
	NiMatrix4 tmp;
	tmp.entry[0].v = p.entry[0].v;
	tmp.entry[1].v = p.entry[1].v;
	tmp.entry[2].v = p.entry[2].v;
	tmp.entry[3].v = { 0, 0, 0, 1 };

	return tmp;
}

RE::NiPoint3 MatMulNi3(RE::NiMatrix3 mat, RE::NiPoint3 p)
{
	return RE::NiPoint3(
		mat.entry[0].v.x * p.x + mat.entry[0].v.y * p.y + mat.entry[0].v.z * p.z,
		mat.entry[1].v.x * p.x + mat.entry[1].v.y * p.y + mat.entry[1].v.z * p.z,
		mat.entry[2].v.x * p.x + mat.entry[2].v.y * p.y + mat.entry[2].v.z * p.z);
}




void SetMatrix33(float a, float b, float c, float d, float e, float f, float g, float h, float i, NiMatrix3& mat)
{
	mat.entry[0].pt[0] = a;
	mat.entry[0].pt[1] = b;
	mat.entry[0].pt[2] = c;
	mat.entry[1].pt[0] = d;
	mat.entry[1].pt[1] = e;
	mat.entry[1].pt[2] = f;
	mat.entry[2].pt[0] = g;
	mat.entry[2].pt[1] = h;
	mat.entry[2].pt[2] = i;
}

NiMatrix3 GetRotationMatrix33(float pitch, float yaw, float roll)
{
	NiMatrix3 m_roll;
	SetMatrix33(cos(roll), -sin(roll), 0,
		sin(roll), cos(roll), 0,
		0, 0, 1,
		m_roll);
	NiMatrix3 m_yaw;
	SetMatrix33(1, 0, 0,
		0, cos(yaw), -sin(yaw),
		0, sin(yaw), cos(yaw),
		m_yaw);
	NiMatrix3 m_pitch;
	SetMatrix33(cos(pitch), 0, sin(pitch),
		0, 1, 0,
		-sin(pitch), 0, cos(pitch),
		m_pitch);
	return m_roll * m_pitch * m_yaw;
}

NiMatrix3 GetRotationMatrix33(NiPoint3 axis, float angle)
{
	float x = axis.x * sin(angle / 2.0f);
	float y = axis.y * sin(angle / 2.0f);
	float z = axis.z * sin(angle / 2.0f);
	float w = cos(angle / 2.0f);
	Quaternion q = Quaternion(x, y, z, w);
	return q.ToRotationMatrix33();
}

NiMatrix3 GetScaleMatrix(float x, float y, float z)
{
	NiMatrix3 ret;
	SetMatrix33(x, 0, 0, 0, y, 0, 0, 0, z, ret);
	return ret;
}

//From https://android.googlesource.com/platform/external/jmonkeyengine/+/59b2e6871c65f58fdad78cd7229c292f6a177578/engine/src/core/com/jme3/math/Quaternion.java
NiMatrix3 Quaternion::ToRotationMatrix33()
{
	float norm = Norm();
	// we explicitly test norm against one here, saving a division
	// at the cost of a test and branch.  Is it worth it?
	float s = (norm == 1.0f) ? 2.0f : (norm > 0.0f) ? 2.0f / norm :
	                                                  0;

	// compute xs/ys/zs first to save 6 multiplications, since xs/ys/zs
	// will be used 2-4 times each.
	float xs = x * s;
	float ys = y * s;
	float zs = z * s;
	float xx = x * xs;
	float xy = x * ys;
	float xz = x * zs;
	float xw = w * xs;
	float yy = y * ys;
	float yz = y * zs;
	float yw = w * ys;
	float zz = z * zs;
	float zw = w * zs;

	// using s=2/norm (instead of 1/norm) saves 9 multiplications by 2 here
	NiMatrix3 mat;
	SetMatrix33(1 - (yy + zz), (xy - zw), (xz + yw),
		(xy + zw), 1 - (xx + zz), (yz - xw),
		(xz - yw), (yz + xw), 1 - (xx + yy),
		mat);

	return mat;
}

//Sarrus rule
float Determinant(NiMatrix3 mat)
{
	return mat.entry[0].pt[0] * mat.entry[1].pt[1] * mat.entry[2].pt[2] + mat.entry[0].pt[1] * mat.entry[1].pt[2] * mat.entry[2].pt[0] + mat.entry[0].pt[2] * mat.entry[1].pt[0] * mat.entry[2].pt[1] - mat.entry[0].pt[2] * mat.entry[1].pt[1] * mat.entry[2].pt[0] - mat.entry[0].pt[1] * mat.entry[1].pt[0] * mat.entry[2].pt[2] - mat.entry[0].pt[0] * mat.entry[1].pt[2] * mat.entry[2].pt[1];
}

NiMatrix3 Inverse(NiMatrix3 mat)
{
	float det = Determinant(mat);
	if (det == 0) {
		NiMatrix3 idmat;
		idmat.MakeIdentity();
		return idmat;
	}
	float a = mat.entry[0].pt[0];
	float b = mat.entry[0].pt[1];
	float c = mat.entry[0].pt[2];
	float d = mat.entry[1].pt[0];
	float e = mat.entry[1].pt[1];
	float f = mat.entry[1].pt[2];
	float g = mat.entry[2].pt[0];
	float h = mat.entry[2].pt[1];
	float i = mat.entry[2].pt[2];
	NiMatrix3 invmat;
	SetMatrix33(e * i - f * h, -(b * i - c * h), b * f - c * e,
		-(d * i - f * g), a * i - c * g, -(a * f - c * d),
		d * h - e * g, -(a * h - b * g), a * e - b * d,
		invmat);
	return invmat * (1.0f / det);
}

NiPoint3 ToDirectionVector(NiMatrix3 mat)
{
	return NiPoint3(mat.entry[2].pt[0], mat.entry[2].pt[1], mat.entry[2].pt[2]);
}

NiPoint3 ToUpVector(NiMatrix3 mat)
{
	return NiPoint3(mat.entry[1].pt[0], mat.entry[1].pt[1], mat.entry[1].pt[2]);
}

//(Rotation Matrix)^-1 * (World pos - Local Origin)
NiPoint3 WorldToLocal(NiPoint3 wpos, NiPoint3 lorigin, NiMatrix3 rot)
{
	NiPoint3 lpos = wpos - lorigin;
	NiMatrix3 invrot = Inverse(rot);


	return NiPoint3(
		invrot.entry[0].pt[0] * lpos.x + invrot.entry[0].pt[1] * lpos.y + invrot.entry[0].pt[2] * lpos.z,
		invrot.entry[1].pt[0] * lpos.x + invrot.entry[1].pt[1] * lpos.y + invrot.entry[1].pt[2] * lpos.z,
		invrot.entry[2].pt[0] * lpos.x + invrot.entry[2].pt[1] * lpos.y + invrot.entry[2].pt[2] * lpos.z);
}

NiPoint3 LocalToWorld(NiPoint3 lpos, NiPoint3 lorigin, NiMatrix3 rot)
{
	return NiPoint3(
			   rot.entry[0].pt[0] * lpos.x + rot.entry[0].pt[1] * lpos.y + rot.entry[0].pt[2] * lpos.z,
			   rot.entry[1].pt[0] * lpos.x + rot.entry[1].pt[1] * lpos.y + rot.entry[1].pt[2] * lpos.z,
			   rot.entry[2].pt[0] * lpos.x + rot.entry[2].pt[1] * lpos.y + rot.entry[2].pt[2] * lpos.z) 
		
	       + lorigin;
}

NiPoint3 CrossProduct(NiPoint3 a, NiPoint3 b)
{
	NiPoint3 ret;
	ret[0] = a[1] * b[2] - a[2] * b[1];
	ret[1] = a[2] * b[0] - a[0] * b[2];
	ret[2] = a[0] * b[1] - a[1] * b[0];
	if (ret[0] == 0 && ret[1] == 0 && ret[2] == 0) {
		if (a[2] != 0) {
			ret[0] = 1;
		} else {
			ret[1] = 1;
		}
	}
	return ret;
}

float DotProduct(NiPoint3 a, NiPoint3 b)
{
	return a.x * b.x + a.y * b.y + a.z * b.z;
}

float Length(NiPoint3 p)
{
	return sqrt(p.x * p.x + p.y * p.y + p.z * p.z);
}

NiPoint3 Normalize(NiPoint3 p)
{
	NiPoint3 ret = p;
	float l = Length(p);
	if (l == 0) {
		ret.x = 1;
		ret.y = 0;
		ret.z = 0;
	} else {
		ret.x /= l;
		ret.y /= l;
		ret.z /= l;
	}
	return ret;
}


inline uint32_t compute_crc32(const uint8_t* data, size_t size)
{
	static constexpr uint32_t crc32_table[256] = { // CRC polynomial 0xEDB88320
		0x00000000, 0x77073096, 0xEE0E612C, 0x990951BA, 0x076DC419, 0x706AF48F, 0xE963A535, 0x9E6495A3,
		0x0EDB8832, 0x79DCB8A4, 0xE0D5E91E, 0x97D2D988, 0x09B64C2B, 0x7EB17CBD, 0xE7B82D07, 0x90BF1D91,
		0x1DB71064, 0x6AB020F2, 0xF3B97148, 0x84BE41DE, 0x1ADAD47D, 0x6DDDE4EB, 0xF4D4B551, 0x83D385C7,
		0x136C9856, 0x646BA8C0, 0xFD62F97A, 0x8A65C9EC, 0x14015C4F, 0x63066CD9, 0xFA0F3D63, 0x8D080DF5,
		0x3B6E20C8, 0x4C69105E, 0xD56041E4, 0xA2677172, 0x3C03E4D1, 0x4B04D447, 0xD20D85FD, 0xA50AB56B,
		0x35B5A8FA, 0x42B2986C, 0xDBBBC9D6, 0xACBCF940, 0x32D86CE3, 0x45DF5C75, 0xDCD60DCF, 0xABD13D59,
		0x26D930AC, 0x51DE003A, 0xC8D75180, 0xBFD06116, 0x21B4F4B5, 0x56B3C423, 0xCFBA9599, 0xB8BDA50F,
		0x2802B89E, 0x5F058808, 0xC60CD9B2, 0xB10BE924, 0x2F6F7C87, 0x58684C11, 0xC1611DAB, 0xB6662D3D,
		0x76DC4190, 0x01DB7106, 0x98D220BC, 0xEFD5102A, 0x71B18589, 0x06B6B51F, 0x9FBFE4A5, 0xE8B8D433,
		0x7807C9A2, 0x0F00F934, 0x9609A88E, 0xE10E9818, 0x7F6A0DBB, 0x086D3D2D, 0x91646C97, 0xE6635C01,
		0x6B6B51F4, 0x1C6C6162, 0x856530D8, 0xF262004E, 0x6C0695ED, 0x1B01A57B, 0x8208F4C1, 0xF50FC457,
		0x65B0D9C6, 0x12B7E950, 0x8BBEB8EA, 0xFCB9887C, 0x62DD1DDF, 0x15DA2D49, 0x8CD37CF3, 0xFBD44C65,
		0x4DB26158, 0x3AB551CE, 0xA3BC0074, 0xD4BB30E2, 0x4ADFA541, 0x3DD895D7, 0xA4D1C46D, 0xD3D6F4FB,
		0x4369E96A, 0x346ED9FC, 0xAD678846, 0xDA60B8D0, 0x44042D73, 0x33031DE5, 0xAA0A4C5F, 0xDD0D7CC9,
		0x5005713C, 0x270241AA, 0xBE0B1010, 0xC90C2086, 0x5768B525, 0x206F85B3, 0xB966D409, 0xCE61E49F,
		0x5EDEF90E, 0x29D9C998, 0xB0D09822, 0xC7D7A8B4, 0x59B33D17, 0x2EB40D81, 0xB7BD5C3B, 0xC0BA6CAD,
		0xEDB88320, 0x9ABFB3B6, 0x03B6E20C, 0x74B1D29A, 0xEAD54739, 0x9DD277AF, 0x04DB2615, 0x73DC1683,
		0xE3630B12, 0x94643B84, 0x0D6D6A3E, 0x7A6A5AA8, 0xE40ECF0B, 0x9309FF9D, 0x0A00AE27, 0x7D079EB1,
		0xF00F9344, 0x8708A3D2, 0x1E01F268, 0x6906C2FE, 0xF762575D, 0x806567CB, 0x196C3671, 0x6E6B06E7,
		0xFED41B76, 0x89D32BE0, 0x10DA7A5A, 0x67DD4ACC, 0xF9B9DF6F, 0x8EBEEFF9, 0x17B7BE43, 0x60B08ED5,
		0xD6D6A3E8, 0xA1D1937E, 0x38D8C2C4, 0x4FDFF252, 0xD1BB67F1, 0xA6BC5767, 0x3FB506DD, 0x48B2364B,
		0xD80D2BDA, 0xAF0A1B4C, 0x36034AF6, 0x41047A60, 0xDF60EFC3, 0xA867DF55, 0x316E8EEF, 0x4669BE79,
		0xCB61B38C, 0xBC66831A, 0x256FD2A0, 0x5268E236, 0xCC0C7795, 0xBB0B4703, 0x220216B9, 0x5505262F,
		0xC5BA3BBE, 0xB2BD0B28, 0x2BB45A92, 0x5CB36A04, 0xC2D7FFA7, 0xB5D0CF31, 0x2CD99E8B, 0x5BDEAE1D,
		0x9B64C2B0, 0xEC63F226, 0x756AA39C, 0x026D930A, 0x9C0906A9, 0xEB0E363F, 0x72076785, 0x05005713,
		0x95BF4A82, 0xE2B87A14, 0x7BB12BAE, 0x0CB61B38, 0x92D28E9B, 0xE5D5BE0D, 0x7CDCEFB7, 0x0BDBDF21,
		0x86D3D2D4, 0xF1D4E242, 0x68DDB3F8, 0x1FDA836E, 0x81BE16CD, 0xF6B9265B, 0x6FB077E1, 0x18B74777,
		0x88085AE6, 0xFF0F6A70, 0x66063BCA, 0x11010B5C, 0x8F659EFF, 0xF862AE69, 0x616BFFD3, 0x166CCF45,
		0xA00AE278, 0xD70DD2EE, 0x4E048354, 0x3903B3C2, 0xA7672661, 0xD06016F7, 0x4969474D, 0x3E6E77DB,
		0xAED16A4A, 0xD9D65ADC, 0x40DF0B66, 0x37D83BF0, 0xA9BCAE53, 0xDEBB9EC5, 0x47B2CF7F, 0x30B5FFE9,
		0xBDBDF21C, 0xCABAC28A, 0x53B39330, 0x24B4A3A6, 0xBAD03605, 0xCDD70693, 0x54DE5729, 0x23D967BF,
		0xB3667A2E, 0xC4614AB8, 0x5D681B02, 0x2A6F2B94, 0xB40BBE37, 0xC30C8EA1, 0x5A05DF1B, 0x2D02EF8D
	};

	uint32_t crc = 0xFFFFFFFF;
	for (; size != 0; --size, ++data)
		crc = (crc >> 8) ^ crc32_table[(crc ^ (*data)) & 0xFF];
	return ~crc;
}
